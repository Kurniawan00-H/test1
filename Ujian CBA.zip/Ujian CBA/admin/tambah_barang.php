<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode_barang = mysqli_real_escape_string($conn, $_POST['kode_barang']);
    $nama_barang = mysqli_real_escape_string($conn, $_POST['nama_barang']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);
    
    $query = "INSERT INTO barang (kode_barang, nama_barang, harga, stok) VALUES ('$kode_barang', '$nama_barang', '$harga', '$stok')";
    if (mysqli_query($conn, $query)) {
        header("Location: data_barang.php");
        exit;
    } else {
        $error = "Gagal menambah data!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="admin">
    <header class="header">
        <a href="index.php" class="header-brand">ADMIN PANEL</a>
        <div class="header-user">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn btn-ghost btn-sm">Keluar</a>
        </div>
    </header>
    <div class="layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="index.php" class="nav-link">📊 Dashboard</a>
                <a href="data_barang.php" class="nav-link active">📦 Data Barang</a>
            </nav>
        </aside>
        <main class="main">
            <div class="page-header">
                <div>
                    <h1 class="page-title">Tambah Barang</h1>
                    <p class="page-subtitle">Masukkan data barang baru</p>
                </div>
                <a href="data_barang.php" class="btn btn-ghost">← Kembali</a>
            </div>
            <div class="form-card">
                <div class="form-card-header">
                    <h2>Form Tambah Barang</h2>
                </div>
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger" style="margin: 24px 36px 0 36px;"><?= $error ?></div>
                <?php endif; ?>
                <form method="POST" action="" class="form-card-body">
                    <div class="form-group">
                        <label>Kode Barang</label>
                        <input type="text" name="kode_barang" placeholder="Contoh: BRG001" required autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Nama Barang</label>
                        <input type="text" name="nama_barang" placeholder="Masukkan nama barang" required autocomplete="off">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Harga (Rp)</label>
                            <input type="number" name="harga" placeholder="0" required>
                        </div>
                        <div class="form-group">
                            <label>Stok</label>
                            <input type="number" name="stok" placeholder="0" required>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">💾 Simpan</button>
                        <a href="data_barang.php" class="btn btn-ghost">Batal</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
