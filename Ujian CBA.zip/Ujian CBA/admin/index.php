<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}
include '../config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="admin">
    <header class="header">
        <a href="index.php" class="header-brand">ADMIN PANEL</a>
        <div class="header-user">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn btn-ghost btn-sm">Keluar</a>
        </div>
    </header>
    <div class="layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="index.php" class="nav-link active">📊 Dashboard</a>
                <a href="data_barang.php" class="nav-link">📦 Data Barang</a>
            </nav>
        </aside>
        <main class="main">
            <div class="page-header">
                <div>
                    <h1 class="page-title">Dashboard</h1>
                    <p class="page-subtitle">Selamat datang di panel administrasi</p>
                </div>
            </div>
            <div class="welcome-card">
                <h2>Halo, <?= htmlspecialchars($_SESSION['username']) ?>! 👋</h2>
                <p>Kamu berhasil masuk ke sistem admin. Gunakan menu di samping untuk mengelola data barang.</p>
            </div>
        </main>
    </div>
</body>
</html>
