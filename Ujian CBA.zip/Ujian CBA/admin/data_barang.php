<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}
include '../config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Barang - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="admin">
    <header class="header">
        <a href="index.php" class="header-brand">ADMIN PANEL</a>
        <div class="header-user">
            <span>👤 <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn btn-ghost btn-sm">Keluar</a>
        </div>
    </header>
    <div class="layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="index.php" class="nav-link">📊 Dashboard</a>
                <a href="data_barang.php" class="nav-link active">📦 Data Barang</a>
            </nav>
        </aside>
        <main class="main">
            <div class="page-header">
                <div>
                    <h1 class="page-title">Data Barang</h1>
                    <p class="page-subtitle">Kelola inventori barang Anda</p>
                </div>
                <a href="tambah_barang.php" class="btn btn-primary">+ Tambah Barang</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Daftar Barang</h2>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th style="width: 60px;">No</th>
                                <th>Kode Barang</th>
                                <th>Nama Barang</th>
                                <th>Harga</th>
                                <th>Stok</th>
                                <th style="width: 150px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            $query = mysqli_query($conn, "SELECT * FROM barang ORDER BY id DESC");
                            if(mysqli_num_rows($query) == 0):
                            ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 40px; color: #64748b;">Belum ada data barang</td>
                            </tr>
                            <?php else: while($data = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><strong><?= htmlspecialchars($data['kode_barang']) ?></strong></td>
                                <td><?= htmlspecialchars($data['nama_barang']) ?></td>
                                <td>Rp <?= number_format($data['harga'], 0, ',', '.') ?></td>
                                <td><?= $data['stok'] ?></td>
                                <td>
                                    <div class="actions">
                                        <a href="edit_barang.php?id=<?= $data['id'] ?>" class="btn btn-ghost btn-sm">✏️ Edit</a>
                                        <a href="hapus_barang.php?id=<?= $data['id'] ?>" class="btn btn-ghost btn-sm" onclick="return confirm('Yakin ingin menghapus barang ini?')">🗑️ Hapus</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
