# Aplikasi Login & CRUD Admin PHP Native

Aplikasi sederhana untuk form login dan tampilan admin dengan fitur CRUD (Create, Read, Update, Delete) menggunakan PHP Native dan terhubung dengan XAMPP (MySQL).

## Fitur
- Halaman Login
- Dashboard Admin
- CRUD Data Barang (Tambah, Lihat, Edit, Hapus)
- Session Login/Logout

## Instalasi
1. Pastikan XAMPP sudah terinstall dan running (Apache & MySQL)
2. Copy folder `Ujian CBA` ke `C:\xampp\htdocs\`
3. Buka browser dan akses `http://localhost/Ujian%20CBA/install.php` untuk membuat database dan tabel
4. Setelah berhasil, akses `http://localhost/Ujian%20CBA/login.php`

## Login Default
- Username: `admin`
- Password: `admin`

## Struktur Database
Database: `ujian_cba`

Tabel:
- `users` (id, username, password, role)
- `barang` (id, kode_barang, nama_barang, harga, stok)

## Struktur File
```
Ujian CBA/
├── admin/
│   ├── data_barang.php
│   ├── edit_barang.php
│   ├── hapus_barang.php
│   ├── index.php
│   ├── logout.php
│   └── tambah_barang.php
├── config/
│   └── koneksi.php
├── assets/
│   ├── css/
│   └── js/
├── install.php
├── login.php
└── README.md
```

## Catatan
- Password disimpan plain text untuk kebutuhan pembelajaran
- Untuk produksi sebaiknya menggunakan `password_hash()`
