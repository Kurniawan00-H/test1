<?php
// File untuk membuat database dan tabel
$host = 'localhost';
$user = 'root';
$pass = '';

$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Buat database
$sql_db = "CREATE DATABASE IF NOT EXISTS ujian_cba";
if (mysqli_query($conn, $sql_db)) {
    echo "Database berhasil dibuat<br>";
} else {
    echo "Error: " . mysqli_error($conn) . "<br>";
}

mysqli_select_db($conn, 'ujian_cba');

// Buat tabel users
$sql_users = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    role VARCHAR(20) DEFAULT 'admin'
)";
if (mysqli_query($conn, $sql_users)) {
    echo "Tabel users berhasil dibuat<br>";
} else {
    echo "Error: " . mysqli_error($conn) . "<br>";
}

// Buat tabel barang
$sql_barang = "CREATE TABLE IF NOT EXISTS barang (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    kode_barang VARCHAR(20) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    harga INT(11) NOT NULL,
    stok INT(11) NOT NULL
)";
if (mysqli_query($conn, $sql_barang)) {
    echo "Tabel barang berhasil dibuat<br>";
} else {
    echo "Error: " . mysqli_error($conn) . "<br>";
}

// Tambah user default
$cek_user = mysqli_query($conn, "SELECT * FROM users WHERE username='admin'");
if (mysqli_num_rows($cek_user) == 0) {
    $sql_insert = "INSERT INTO users (username, password, role) VALUES ('admin', 'admin', 'admin')";
    if (mysqli_query($conn, $sql_insert)) {
        echo "User default berhasil ditambahkan (username: admin, password: admin)<br>";
    }
}

mysqli_close($conn);
?>
<a href="login.php">Ke Halaman Login</a>
